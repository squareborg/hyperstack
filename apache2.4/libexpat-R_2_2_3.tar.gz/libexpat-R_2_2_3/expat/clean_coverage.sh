rm -r build__*
rm -r coverage__*
rm -r source__*
